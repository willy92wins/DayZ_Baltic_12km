import argparse, hashlib, json, os, subprocess
from pathlib import Path
R=Path(r'E:\DayZ-Baltic-Build\shape-repair-20261025')
W=Path(r'C:\Users\guill\OneDrive\Documentos\DayZ Projects\DayZ_Baltic_12km_dev\.claude\worktrees\handoff-astra-map-review-6d301c')
PY=Path(r'C:\Users\guill\Documents\Codex\2026-09-29\vamos\work\gis-env\Scripts\python.exe')
a=argparse.ArgumentParser();a.add_argument('order',type=int);ns=a.parse_args()
d=R/'server-baseline-ab-v2'/f'pass-{ns.order:02}'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
before=load(d/'before.json');run=load(d/'run.json');host=load(d/'host-identity.json')
assert host['run_id']==run['run_id'] and host['pid']==run['process']['pid']
assert not host['navmesh_data_server'] and not run['client_started']
assert run['server_binding']=='BOUND' and run['server_run_id']==run['run_id']
assert Path(host['mission_path'])/'init.c'==Path(before['artifacts']['mission'])
for role,key in [('mission','mission_sha256'),('executable','executable_file_sha256'),('server_config','server_config_sha256')]:
    assert host[key]==before['inputs'][before['artifacts'][role]],role
vanilla=Path(before['artifacts']['executable']).parent/'Addons'
actual=set(p.resolve() for p in vanilla.glob('*.pbo'))
actual.update(Path(p).resolve() for p in host['package_hashes'])
assert actual==set(Path(p).resolve() for p in before['packages']),'Actual loaded package inventory differs'
expected_packages={Path(p).resolve():h for p,h in before['packages'].items()}
for p,h in host['package_hashes'].items():assert expected_packages[Path(p).resolve()]==h,p
engine=d/run['profile_log']
args=[str(PY),'-I',str(W/'tools/performance/bind_server_baseline_ev112.py'),'finish','--snapshot',str(d/'before.json'),'--run-id',run['run_id'],'--process-id',str(run['process']['pid']),'--start-utc',run['process']['creation_time_utc'],'--engine',str(engine),'--host',str(d/'host.jsonl'),'--out',str(d/'reference.json')]
for name,cmd in [('binding',args),('consumer',[str(PY),'-I',str(W/'tools/performance/read_server_baseline_ev112.py'),'--reference',str(d/'reference.json'),'--engine',str(engine),'--host',str(d/'host.jsonl'),'--out',str(d/'result.json')])]:
    proc=subprocess.run(cmd,cwd=W,capture_output=True,text=True,encoding='utf-8')
    (d/(name+'.stdout.log')).write_text(proc.stdout,encoding='utf-8')
    (d/(name+'.stderr.log')).write_text(proc.stderr,encoding='utf-8')
    if proc.returncode:
        print(json.dumps({'phase':name,'returncode':proc.returncode,'stderr':proc.stderr[-1500:],'stdout':proc.stdout[-1500:]}))
        raise SystemExit(proc.returncode)
result=load(d/'result.json')
print(json.dumps({k:result.get(k) for k in ('status','world','host_samples','measurement_samples','host_measurement_seconds','cpu_percent_one_logical_core','working_set_mib','private_mib','private_bytes_mib')},indent=2))
