from pathlib import Path
import subprocess,sys,json,hashlib
R=Path(__file__).parent/'warmup-boundary-review'
W=Path(r'C:\Users\guill\OneDrive\Documentos\DayZ Projects\DayZ_Baltic_12km_dev\.claude\worktrees\handoff-astra-map-review-6d301c')
phase=sys.argv[1]
args=[sys.executable,'-I','-m','unittest','discover','-s','tests']
if phase=='red':args+=['-p','test_terrain_perf_warmup.py','-v']
p=subprocess.run(args,cwd=W,capture_output=True)
(R/(phase+'.stdout.log')).write_bytes(p.stdout);(R/(phase+'.stderr.log')).write_bytes(p.stderr)
paths=[W/'tools/navigation/verify_terrain_perf.py',W/'tests/test_terrain_perf_warmup.py',W/'tests/fixtures/server-baseline-roundoff.log']
r=dict(phase=phase,command=args,returncode=p.returncode,inputs={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths})
(R/(phase+'.json')).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(p.stderr.decode('utf-8',errors='replace')[-2000:])
raise SystemExit(p.returncode)
