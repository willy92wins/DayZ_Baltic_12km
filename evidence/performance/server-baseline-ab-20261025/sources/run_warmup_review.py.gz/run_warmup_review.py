from pathlib import Path
import subprocess,json,time
R=Path(__file__).parent/'warmup-boundary-review'
W=Path('C:/Users/guill/OneDrive/Documentos/DayZ Projects/DayZ_Baltic_12km_dev/.claude/worktrees/handoff-astra-map-review-6d301c')
args=['C:/Users/guill/.local/bin/claude.exe','--print','--safe-mode','--model','claude-fable-5-1','--tools','Read,Glob,Grep','--allowedTools','Read,Glob,Grep','--output-format','json','--no-session-persistence']
with (R/'review-response.json').open('wb') as out,(R/'review-stderr.log').open('wb') as err:
    p=subprocess.Popen(args,cwd=W,stdin=subprocess.PIPE,stdout=out,stderr=err,creationflags=0x08000000)
    (R/'review-process.json').write_text(json.dumps(dict(pid=p.pid,start_epoch=time.time(),args=args),indent=2))
    try:p.communicate((R/'review-brief.md').read_bytes(),timeout=600)
    except subprocess.TimeoutExpired:
        p.terminate();p.wait(timeout=30);raise
    print('FABLE_EXIT',p.returncode)
    raise SystemExit(p.returncode)

