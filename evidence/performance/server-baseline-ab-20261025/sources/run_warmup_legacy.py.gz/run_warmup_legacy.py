from pathlib import Path
import subprocess,sys,json,hashlib
R=Path(__file__).parent/'warmup-boundary-review'
W=Path(r'C:\Users\guill\OneDrive\Documentos\DayZ Projects\DayZ_Baltic_12km_dev\.claude\worktrees\handoff-astra-map-review-6d301c')
artifact=W/'evidence/performance/native-baseline-v1/negative-controls.json'
before=artifact.read_bytes() if artifact.exists() else None
code="import sys,runpy; from pathlib import Path; p=Path('tools/navigation').resolve(); sys.path.insert(0,str(p)); runpy.run_path(str(p/'test_perf_evidence_controls.py'),run_name='__main__')"
p=subprocess.run([sys.executable,'-I','-c',code],cwd=W,capture_output=True)
(R/'legacy.stdout.log').write_bytes(p.stdout);(R/'legacy.stderr.log').write_bytes(p.stderr)
after=artifact.read_bytes()
if before is not None:assert json.loads(before)==json.loads(after),'Legacy verdicts changed'
if before is not None and before!=after:
    assert artifact.read_bytes()==after
    artifact.write_bytes(before)
result=dict(returncode=p.returncode,controls=json.loads(after),original_artifact_present=before is not None,original_artifact_unchanged=(artifact.read_bytes()==before) if before is not None else None,validator_sha256=hashlib.sha256((W/'tools/navigation/verify_terrain_perf.py').read_bytes()).hexdigest(),note='Executed actual legacy regression script with isolated Python and explicit module path; no engine capture changed. This sparse worktree had no negative-controls.json; the script creates its current result.')
(R/'legacy.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
raise SystemExit(p.returncode)
