const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root='E:/DayZ-Baltic-Build/shape-repair-20261025';
const source=fs.readFileSync(root+'/orchestrate_nav_c_retry_v3.js','utf8');
const digest=s=>crypto.createHash('sha256').update(s).digest('hex');
const runId='11111111-2222-4333-8444-555555555555',start='2026-10-26T11:00:00Z';
async function scenario(name,code=source) {
 const calls=[],writes={},notifications=[];
 let launched=false,active=false,closed=false,foreign=false,captureCount=0,pollCount=0,cancelled=false;
 const failedWrapper=name==='wrapper_failure'||name==='cancel_failure';
 const finalFailure=name==='final_status_failure',rptFailure=name==='rpt_failure';
 let statusFailed=false;
 const ok=output=>({exit_code:0,output:output||''});
 const tools={
  async exec_command(a){
   const c=a.cmd;calls.push(c);
   if(c.startsWith('Get-Content -LiteralPath')){
    if(c.includes('launch-inputs.json'))return ok(JSON.stringify({status:'READY_AFTER_CODE_REVIEW',observer_sha256:'observer'}));
    if(c.includes('/attached.json'))return ok(JSON.stringify({status:'ATTACHED',handle_retained:true,process_id:123,start_utc:start,observer_sha256:'observer',executable_sha256:'a500be804ffed5cde369337aeb6ab477ef5ee0b5015764be2b1953c85ec3060d'}));
    if(c.includes('/generation.json'))return ok(JSON.stringify({status:'GENERATED_FILE_PENDING_STRUCTURAL_AND_ENGINE_VALIDATION'}));
    return ok('progress');
   }
   if(c.startsWith('Test-Path'))return ok(c.includes('/attached.json')?'True':'False');
   if(c.includes("-File './tools/navigation/observe_owned_server_exit.ps1'"))return {session_id:88,output:''};
   if(c.includes("-I './tools/navigation/generate_navmesh_console.py'"))return {session_id:77,output:''};
   if(c.includes('/capture_nav_c_generator.ps1')){
    captureCount++;
    if(name==='delayed_capture'&&captureCount<4)return {exit_code:1,output:'Exactly one generator child of this run required'};
    return ok();
   }
   if(c.includes('/cancel_owned_nav_c_generator.ps1')){
    if(name==='cancel_failure')return {exit_code:1,output:'Generator identity could not be confirmed'};
    cancelled=true;return ok();
   }
   if(c.includes('/copy_owned_server_rpt.ps1')&&rptFailure)return {exit_code:1,output:'RPT fixture read error'};
   return ok();
  },
  async write_stdin(a){
   calls.push('poll:'+a.session_id);
   if(a.session_id===88)return ok('observer finished');
   assert.equal(a.session_id,77);
   pollCount++;
   if(name==='delayed_capture'&&captureCount<4)return {session_id:77,output:''};
   if(name==='foreign_owner'&&!foreign){foreign=true;active=false;return {session_id:77,output:''};}
   return {exit_code:failedWrapper||cancelled?1:0,output:failedWrapper?'wrapper failed':''};
  },
  async apply_patch(p){const m=p.match(/\*\*\* Add File: (.+)\n([\s\S]+)\n\*\*\* End Patch/);assert(m);writes[m[1]]=JSON.parse(m[2].split('\n').map(x=>x.slice(1)).join('\n'));return {};},
  async mcp__dayz_mcp_130__session_status(){
   calls.push('status');
   if(finalFailure&&closed&&!active&&!statusFailed){statusFailed=true;throw Error('Final status fixture failure');}
   return {self:{state:active?'active':'none'},owner:foreign?{id:'foreign'}:null,box:{occupied:launched&&!closed,runs:launched&&!closed?[{run_id:runId,state:foreign?'RUNNING':'RUNNING_IDLE'}]:[]},pending_commands:0,cleanup_degraded:[]};
  },
  async mcp__dayz_mcp_130__dayz_test_run(a){calls.push('launch');assert.equal(a.mode,'server');assert.equal(a.takeover,false);launched=true;return {status:'succeeded',run_id:runId};},
  async mcp__dayz_mcp_130__session_acquire_wait(){calls.push('acquire');active=true;return {lease_token:'fake-lease-never-live'};},
  async mcp__dayz_mcp_130__session_heartbeat(){calls.push('beat');if(foreign)throw Error('Foreign owner');return {};},
  async mcp__dayz_mcp_130__bridge_status(){return {server_peer:{binding_state:'BOUND',run_id:runId,version_state:'ok'},lifecycle:{runs:[{run_id:runId,processes:[{pid:123,creation_time_utc:start,role:'server'}],client_diagnostics:[{state:'not_started'}]}]}};},
  async mcp__dayz_mcp_130__dayz_test_close(a){calls.push('close');assert(active&&!foreign);assert.equal(a.run_id,runId);closed=true;return {run_retired:true};},
  async mcp__dayz_mcp_130__session_release(){calls.push('release');active=false;return {};},
 };
 const f=new Function('tools','load','store','notify','setTimeout',code+'\nreturn retryCNavigationAfterHumanClose;')(tools,()=>'(x)=>x',()=>{},x=>notifications.push(x),f=>f());
 let error=null;try{await f();}catch(e){error=e.message;}
 assert.equal(calls.filter(x=>x==='launch').length,1);
 if(name==='success'||name==='delayed_capture'){assert.equal(error,null);assert(closed&&!active);}
 else assert(error,'Injected failure must fail');
 if(name==='delayed_capture')assert.equal(captureCount,4);
 if(name==='wrapper_failure')assert(cancelled&&closed&&!active,'Failed wrapper must still cancel exact generator before closing');
 if(name==='cancel_failure'){assert(!closed&&active,'Unconfirmed cancel must preserve own run for recovery');assert(!calls.includes('release'));assert.equal(notifications.at(-1).state,'C_NAV_REQUIRES_OWNED_RECOVERY');}
 if(finalFailure||rptFailure){assert(calls.includes('poll:88'),'Observer completion must still be inspected');assert(closed&&!active);}
 if(name==='foreign_owner'){assert(cancelled&&!closed&&!active);assert(!calls.includes('close'));assert(!calls.includes('release'));}
 const summary=Object.values(writes).find(x=>x.status==='OWNED_RECOVERY_REQUIRED'||x.status==='INCONCLUSIVE'||x.status==='GENERATION_STAGE_COMPLETE_PENDING_VALIDATION');
 assert(summary,'Durable completion required');
 return {name,passed:true,captureCount,pollCount,closed,released:calls.includes('release'),cancelled,error};
}
(async()=>{
 const cases=[];for(const name of ['success','delayed_capture','wrapper_failure','cancel_failure','final_status_failure','rpt_failure','foreign_owner'])cases.push(await scenario(name));
 const mutations=[
 ['single_capture',source.replace('i<24&&!captured','i<1&&!captured'),'delayed_capture'],
 ['skip_cancel_after_wrapper_error',source.replace("genDone=q.exit_code===0&&(await read(out+'/generation.json')).status==='GENERATED_FILE_PENDING_STRUCTURAL_AND_ENGINE_VALIDATION';if(!genDone)throw Error('Generator failed: '+q.output);","genDone=true;if(q.exit_code!==0)throw Error('Generator failed');"),'wrapper_failure'],
 ['close_with_unconfirmed_cancel',source.replace('preserveForRecovery=true;','preserveForRecovery=false;'),'cancel_failure']
 ];
 const negatives=[];
 for(const [name,mutated,test] of mutations){assert.notEqual(mutated,source);let rejected=false;try{await scenario(test,mutated);}catch{rejected=true;}assert(rejected,'Mutation survived: '+name);negatives.push({name,rejected});}
 const result={status:'CONTROL_FLOW_PASS',coordinator_sha256:digest(source),harness_sha256:digest(fs.readFileSync(__filename)),scope:'Mocked tools test ownership and cleanup flow; not native DayZ or MCP acceptance',cases,negative_mutations:negatives};
 const out=root+'/nav-c-retry-review/coordinator-control-flow.json';
 fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
