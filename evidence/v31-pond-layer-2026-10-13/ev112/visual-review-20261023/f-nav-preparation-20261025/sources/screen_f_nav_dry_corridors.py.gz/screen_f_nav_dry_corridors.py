from pathlib import Path
import sys,json,hashlib
import numpy as np
W=Path(r'C:\Users\guill\OneDrive\Documentos\DayZ Projects\DayZ_Baltic_12km_dev\.claude\worktrees/handoff-astra-map-review-6d301c')
R=Path(__file__).parent
e=R/'guarded-relief-batch-e-merged/terrain-buried.npz';f=R/'rectangle-pilot-f-merged/terrain-buried.npz';fp=R/'rectangle-pilot-f-merged/bury-work/fp0/footprint.npz'
he=np.load(e)['heights'];hf=np.load(f)['heights'];water=np.load(fp)
plane=water['plane'];field=water['field']
changed=np.abs(hf-he)>0
rr,cc=np.where(changed)
result=dict(status='READ_ONLY_F_PATCH_DRY_CORRIDOR_SCREEN',changed_vertices=int(changed.sum()),changed_vertex_bounds_xz=[float(cc.min()*6),float(12282-rr.max()*6),float(cc.max()*6),float(12282-rr.min()*6)],policy=dict(centers_x=list(range(2892,2947,6)),centers_z=list(range(6804,6865,6)),half_extents_m=[12,18,24,30],min_corner_clearance_m=.05,min_strong_cells=2,strong_delta_m=.1,sample_spacing_max_m=1.,ranking='Maximize distinct crossed cells containing >=0.1m E/F change; then minimize midpoint distance to(2916,6834), then prefer longer segment. No native result used.'),routes=[],limits=['Conservative dry cells do not prove absence of 3D object obstructions.','Coordinates screened before any new E/F native queries; no query result selected or discarded.'])
for name,direction in [('ew',(1,0)),('ns',(0,1)),('ne_sw',(1,1)),('nw_se',(1,-1))]:
    choices=[]
    for cx in result['policy']['centers_x']:
      for cz in result['policy']['centers_z']:
       for half in result['policy']['half_extents_m']:
        start=np.array([cx,cz])-np.array(direction)*half;end=np.array([cx,cz])+np.array(direction)*half
        length=float(np.linalg.norm(end-start));xy=np.linspace(start,end,int(np.ceil(length))+1)
        col=np.floor(xy[:,0]/6).astype(int);row=np.floor((12282-xy[:,1])/6).astype(int)
        levels=np.where(np.isfinite(plane[row,col])[:,None],field[row,col],.75)
        if not np.isfinite(levels).all():continue
        ec=np.stack([he[row,col],he[row,col+1],he[row+1,col],he[row+1,col+1]],axis=1)
        fc=np.stack([hf[row,col],hf[row,col+1],hf[row+1,col],hf[row+1,col+1]],axis=1)
        clearance=float(np.min(np.minimum(ec,fc)-np.max(levels,axis=1)[:,None]))
        if clearance<.05:continue
        cells=set(zip(row[np.max(np.abs(fc-ec),axis=1)>=.1].tolist(),col[np.max(np.abs(fc-ec),axis=1)>=.1].tolist()))
        if len(cells)<2:continue
        choices.append((len(cells),-((cx-2916)**2+(cz-6834)**2),length,dict(name='f_patch_'+name,start_xz=start.tolist(),end_xz=end.tolist(),length_m=length,min_conservative_corner_dry_clearance_m=clearance,strong_changed_cells=[list(x) for x in sorted(cells)])))
    choices.sort(key=lambda x:x[:3],reverse=True)
    result['routes'].append(dict(direction=name,valid_geometric_candidates=len(choices),selected=choices[0][3] if choices else None))
result['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [e,f,fp,Path(__file__)]}
path=R/'f-nav-dry-corridors.json';assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('policy','inputs')},indent=2))
