from pathlib import Path
import sys,json,hashlib
import numpy as np
W=Path(r'C:\Users\guill\OneDrive\Documentos\DayZ Projects\DayZ_Baltic_12km_dev\.claude\worktrees\handoff-astra-map-review-6d301c')
R=Path(__file__).parent
sys.path.insert(0,str(W/'tools/terrain'))
from v30_common import tri_sample
e=R/'guarded-relief-batch-e-merged/terrain-buried.npz'
f=R/'rectangle-pilot-f-merged/terrain-buried.npz'
fp=R/'rectangle-pilot-f-merged/bury-work/fp0/footprint.npz'
he=np.load(e)['heights'];hf=np.load(f)['heights'];water=np.load(fp)
routes=[('f_patch_ew',[2886,6834],[2946,6834]),('f_patch_ns',[2916,6804],[2916,6864]),('f_patch_ne_sw',[2892,6810],[2940,6858]),('f_patch_nw_se',[2892,6858],[2940,6810])]
out=[]
for name,start,end in routes:
    length=float(np.linalg.norm(np.array(end)-start));xy=np.linspace(start,end,int(np.ceil(length))+1)
    col=np.floor(xy[:,0]/6).astype(int);row=np.floor((12282-xy[:,1])/6).astype(int)
    levels=np.where(np.isfinite(water['plane'][row,col])[:,None],water['field'][row,col],.75)
    ec=np.stack([he[row,col],he[row,col+1],he[row+1,col],he[row+1,col+1]],axis=1)
    fc=np.stack([hf[row,col],hf[row,col+1],hf[row+1,col],hf[row+1,col+1]],axis=1)
    clearance=float(np.min(np.minimum(ec,fc)-np.max(levels,axis=1)[:,None]))
    out.append(dict(name=name,start_xz=start,end_xz=end,length_m=length,min_conservative_corner_dry_clearance_m=clearance,finite_water_levels=bool(np.isfinite(levels).all()),crossed_changed_cells=int(np.any(ec!=fc,axis=1).sum()),endpoint_y_e=[float(tri_sample(he,*p))+.1 for p in (start,end)],endpoint_y_f=[float(tri_sample(hf,*p))+.1 for p in (start,end)]))
result=dict(status='READ_ONLY_F_PATCH_NAV_ROUTE_DISCOVERY',routes=out,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [e,f,fp,W/'tools/terrain/v30_common.py']},limits=['Geometric dry corridor only; static object obstruction and native route behavior are not inferred.','No reference or mission created; routes must be frozen before any E/F native comparison.'])
(R/'f-nav-route-discovery.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
